--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: itg_saude; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA itg_saude;


ALTER SCHEMA itg_saude OWNER TO postgres;

--
-- Name: uuid_generate_v4(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.uuid_generate_v4() RETURNS uuid
    LANGUAGE c STRICT
    AS '$libdir/uuid-ossp', 'uuid_generate_v4';


ALTER FUNCTION public.uuid_generate_v4() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dados_hospitalares; Type: TABLE; Schema: itg_saude; Owner: postgres
--

CREATE TABLE itg_saude.dados_hospitalares (
    id integer NOT NULL,
    id_paciente integer NOT NULL,
    tipo_sanguineo character varying(3) NOT NULL,
    alergico boolean NOT NULL,
    diabetico boolean NOT NULL
);


ALTER TABLE itg_saude.dados_hospitalares OWNER TO postgres;

--
-- Name: dados_hospitalares_id_seq; Type: SEQUENCE; Schema: itg_saude; Owner: postgres
--

CREATE SEQUENCE itg_saude.dados_hospitalares_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE itg_saude.dados_hospitalares_id_seq OWNER TO postgres;

--
-- Name: dados_hospitalares_id_seq; Type: SEQUENCE OWNED BY; Schema: itg_saude; Owner: postgres
--

ALTER SEQUENCE itg_saude.dados_hospitalares_id_seq OWNED BY itg_saude.dados_hospitalares.id;


--
-- Name: estado_civil; Type: TABLE; Schema: itg_saude; Owner: postgres
--

CREATE TABLE itg_saude.estado_civil (
    id integer NOT NULL,
    estado_civil character varying(15) NOT NULL
);


ALTER TABLE itg_saude.estado_civil OWNER TO postgres;

--
-- Name: paciente; Type: TABLE; Schema: itg_saude; Owner: postgres
--

CREATE TABLE itg_saude.paciente (
    id integer NOT NULL,
    nome_paciente character varying(50) NOT NULL,
    data_nascimente character varying(10) NOT NULL,
    contato_celular character varying(14),
    estado_civil character varying(15) NOT NULL,
    cpf character varying(14) NOT NULL
);


ALTER TABLE itg_saude.paciente OWNER TO postgres;

--
-- Name: paciente_id_seq; Type: SEQUENCE; Schema: itg_saude; Owner: postgres
--

CREATE SEQUENCE itg_saude.paciente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE itg_saude.paciente_id_seq OWNER TO postgres;

--
-- Name: paciente_id_seq; Type: SEQUENCE OWNED BY; Schema: itg_saude; Owner: postgres
--

ALTER SEQUENCE itg_saude.paciente_id_seq OWNED BY itg_saude.paciente.id;


--
-- Name: tipo_acesso; Type: TABLE; Schema: itg_saude; Owner: postgres
--

CREATE TABLE itg_saude.tipo_acesso (
    id integer NOT NULL,
    tipo_acesso character varying(38) NOT NULL
);


ALTER TABLE itg_saude.tipo_acesso OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: itg_saude; Owner: postgres
--

CREATE TABLE itg_saude.usuarios (
    id integer NOT NULL,
    nome_usuario character varying(40) NOT NULL,
    senha_acesso character varying NOT NULL,
    id_tipo_acesso integer
);


ALTER TABLE itg_saude.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: itg_saude; Owner: postgres
--

CREATE SEQUENCE itg_saude.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE itg_saude.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: itg_saude; Owner: postgres
--

ALTER SEQUENCE itg_saude.usuarios_id_seq OWNED BY itg_saude.usuarios.id;


--
-- Name: dados_hospitalares id; Type: DEFAULT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.dados_hospitalares ALTER COLUMN id SET DEFAULT nextval('itg_saude.dados_hospitalares_id_seq'::regclass);


--
-- Name: paciente id; Type: DEFAULT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.paciente ALTER COLUMN id SET DEFAULT nextval('itg_saude.paciente_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.usuarios ALTER COLUMN id SET DEFAULT nextval('itg_saude.usuarios_id_seq'::regclass);


--
-- Data for Name: dados_hospitalares; Type: TABLE DATA; Schema: itg_saude; Owner: postgres
--

COPY itg_saude.dados_hospitalares (id, id_paciente, tipo_sanguineo, alergico, diabetico) FROM stdin;
\.


--
-- Data for Name: estado_civil; Type: TABLE DATA; Schema: itg_saude; Owner: postgres
--

COPY itg_saude.estado_civil (id, estado_civil) FROM stdin;
1	Solteiro(A)
2	Casado(A)
3	Divorciado(A)
4	Separado(A)
5	Viuvo(A)
\.


--
-- Data for Name: paciente; Type: TABLE DATA; Schema: itg_saude; Owner: postgres
--

COPY itg_saude.paciente (id, nome_paciente, data_nascimente, contato_celular, estado_civil, cpf) FROM stdin;
1	Jonathan José Trabach	28/11/2000	(27)99833-5174	Solteiro(A)	140.099.097-14
2	jonathan teste	20/10/2000	(28)99999-9999	Separado(A)	152.022.022-00
3	jonathan teste 1	01/01/0000	(00)00000-0000	Solteiro(A)	000.000.000-00
4	Teste	00/00/0000	(00)00000-0000	Casado(A)	000.000.000-00
5	teste	  /  /    	(  )     -    	Solteiro(A)	   .   .   -  
6	jonathan	00/00/0000	(  )     -    	Divorciado(A)	155.000.001-00
7	jonathan teste	00/00/0000	(  )     -    	Casado(A)	000.000.000-00
8	jonathan teste	00/00/0000	(  )     -    	Casado(A)	000.000.000-00
9	jonathan teste	00/00/0000	(00)00000-0000	Solteiro(A)	000.000.000-00
10	jonathan teste	00/00/0000	(00)00000-0000	Solteiro(A)	140.099.097-14
11	Daniela Benevides Demuner	21/09/1999	(  )     -    	Solteiro(A)	177.563.607-02
12	Daniela Benevides Demuner	21/09/1999	(  )     -    	Solteiro(A)	000.000.000-00
13	Luciana 	00/00/0000	(  )     -    	Solteiro(A)	000.000.000-00
14	luciana 	00/00/0000	(  )     -    	Solteiro(A)	000.000.000-00
\.


--
-- Data for Name: tipo_acesso; Type: TABLE DATA; Schema: itg_saude; Owner: postgres
--

COPY itg_saude.tipo_acesso (id, tipo_acesso) FROM stdin;
1	medico
2	atendente
3	enfermeiro
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: itg_saude; Owner: postgres
--

COPY itg_saude.usuarios (id, nome_usuario, senha_acesso, id_tipo_acesso) FROM stdin;
1	teste	[C@17688dda	\N
2	teste	1234	\N
3	jonathan.trabach	jony4321	\N
4	derione.espindula	derione	\N
5	samuel.ruan	1234	\N
\.


--
-- Name: dados_hospitalares_id_seq; Type: SEQUENCE SET; Schema: itg_saude; Owner: postgres
--

SELECT pg_catalog.setval('itg_saude.dados_hospitalares_id_seq', 1, false);


--
-- Name: paciente_id_seq; Type: SEQUENCE SET; Schema: itg_saude; Owner: postgres
--

SELECT pg_catalog.setval('itg_saude.paciente_id_seq', 14, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: itg_saude; Owner: postgres
--

SELECT pg_catalog.setval('itg_saude.usuarios_id_seq', 5, true);


--
-- Name: dados_hospitalares dados_hospitalares_pkey; Type: CONSTRAINT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.dados_hospitalares
    ADD CONSTRAINT dados_hospitalares_pkey PRIMARY KEY (id);


--
-- Name: estado_civil estado_civil_pkey; Type: CONSTRAINT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.estado_civil
    ADD CONSTRAINT estado_civil_pkey PRIMARY KEY (estado_civil);


--
-- Name: paciente paciente_pkey; Type: CONSTRAINT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.paciente
    ADD CONSTRAINT paciente_pkey PRIMARY KEY (id);


--
-- Name: tipo_acesso pkey_tipo_acesso; Type: CONSTRAINT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.tipo_acesso
    ADD CONSTRAINT pkey_tipo_acesso PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: paciente fk_estado_civil; Type: FK CONSTRAINT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.paciente
    ADD CONSTRAINT fk_estado_civil FOREIGN KEY (estado_civil) REFERENCES itg_saude.estado_civil(estado_civil);


--
-- Name: usuarios usuarios_fk; Type: FK CONSTRAINT; Schema: itg_saude; Owner: postgres
--

ALTER TABLE ONLY itg_saude.usuarios
    ADD CONSTRAINT usuarios_fk FOREIGN KEY (id_tipo_acesso) REFERENCES itg_saude.tipo_acesso(id);


--
-- PostgreSQL database dump complete
--

