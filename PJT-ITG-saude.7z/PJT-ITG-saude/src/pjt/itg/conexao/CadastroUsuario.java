/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pjt.itg.conexao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import pjt.itg.entidades.Usuarios;

/**
 *
 * @author jonathan.trabach
 */
public class CadastroUsuario {
    
    ConexaoDB conecta = new ConexaoDB();
    Usuarios users = new Usuarios();
    
    public void salvarUsuario(Usuarios users){
    conecta.Conexao();
    
        try {
            PreparedStatement pst = conecta.con.prepareStatement("INSERT INTO itg_saude.usuarios\n" +
                                                                 "(nome_usuario, senha_acesso)\n" +
                                                                 "VALUES( ?, ?);");
            
            pst.setString(1, users.getNomeUsuario());
            pst.setString(2, users.getSenhaUsuario());
            pst.execute();
        
            
            JOptionPane.showMessageDialog(null, "Usuario Inserido com Sucesso!");
        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao inserir o Usuario /nError"+ex);
        }
    
    
    conecta.desconectar();
    
    
    }


}
