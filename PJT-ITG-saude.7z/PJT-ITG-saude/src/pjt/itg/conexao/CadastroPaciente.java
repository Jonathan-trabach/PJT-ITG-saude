/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pjt.itg.conexao;

import pjt.itg.entidades.EstadoCivil;
import pjt.itg.entidades.Paciente;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author jonathan.trabach
 */
public class CadastroPaciente {
    
    ConexaoDB conecta = new ConexaoDB();
    Paciente pac = new Paciente();
    EstadoCivil estadoCivil = new EstadoCivil();
    
    public void salvarPaciente(Paciente pac, EstadoCivil estadoCivil){
    conecta.Conexao();
    
        try {
            PreparedStatement pst = conecta.con.prepareStatement("INSERT INTO itg_saude.paciente\n" +
                                                                 "(nome_paciente, data_nascimente, contato_celular, estado_civil, cpf)\n" +
                                                                 "VALUES( ?, ?, ?, ?, ?);");
            
            pst.setString(1, pac.getNome());
            pst.setString(2, pac.getDataNasc());
            pst.setString(3, pac.getContatoFam());
            pst.setString(4, estadoCivil.getEstadoCivil());
            pst.setString(5, pac.getCpf());
            
            pst.execute();
        
            JOptionPane.showMessageDialog(null, "Inserido com Sucesso!");
        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao inserir o Paciente /nError"+ex);
        }
    
    
    conecta.desconectar();
    
    
    }

}
