/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pjt.itg.saude;

/**
 *
 * @author jonathan.trabach
 */
public class PJTITGSaude {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        TelaLogin tl = new TelaLogin();
        
        tl.setVisible(true);
        
    }
    
}
